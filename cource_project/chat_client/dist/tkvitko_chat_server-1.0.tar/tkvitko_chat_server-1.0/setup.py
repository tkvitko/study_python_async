from setuptools import setup

setup(
    name='tkvitko_chat_server',
    version="1.0",
    description="GB Project Async Chat Client",
    author="Taras Kvitko",
    author_email="tkvitko@gmail.com",
    packages=["src"]
)
